﻿using System;

namespace Vehicles
{
    public class Program
    {
        static void Main(string[] args)
        {

            string[] carElements = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
            string[] truckElements = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);

            int intValue = int.Parse(Console.ReadLine());

            string carName = carElements[0];
            double carFuelQuantity = double.Parse(carElements[1]);
            double carLitersConsummtion = double.Parse(carElements[2]);

            string truckName = truckElements[0];
            double truckFuelQuantity = double.Parse(truckElements[1]);
            double truckLitersConsummtion = double.Parse(truckElements[2]);

            Vehicle car = new Car(carFuelQuantity, carLitersConsummtion);
            Vehicle truck = new Truck( truckFuelQuantity, truckLitersConsummtion);

            for (int i = 0; i < intValue; i++)
            {

                string[] stringElements = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);

                if (stringElements[0] == "Drive")
                {
                    if (stringElements[1] == "Car")
                    {
                        car.Drive(double.Parse(stringElements[2]));
                    }
                    else
                    {
                        truck.Drive(double.Parse(stringElements[2]));
                    }
                }
                else if (stringElements[0] == "Refuel")
                {
                    if (stringElements[1] == "Car")
                    {
                        car.Refuel(double.Parse(stringElements[2]));
                    }
                    else
                    {
                        truck.Refuel(double.Parse(stringElements[2]));
                    }
                }   


            }

            Console.WriteLine($"Car: {car.FuelQuantity:f2}");
            Console.WriteLine($"Truck: {truck.FuelQuantity:f2}");


        }
    }
}
