﻿using Gym.Models.Athletes.Contracts;
using Gym.Models.Equipment.Contracts;
using Gym.Models.Gyms.Contracts;
using Gym.Utilities.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Gym.Models.Gyms
{
    public abstract class Gym : IGym
    {
        private string name;
        

        public Gym(string name, int capacity)
        {
            Name = name;
            Capacity = capacity;
         }

        public string Name 
        {
            get {return name; }
            set 
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new ArgumentNullException(ExceptionMessages.InvalidGymName);
                }
                name = value;
            
            }

        }

        public int Capacity { get; set;}  

        //!!!!!!
        public double EquipmentWeight => Equipment.Sum(e => e.Weight);

        public ICollection<IEquipment> Equipment { get; set; }

        public ICollection<IAthlete> Athletes { get; set; }

        public void AddAthlete(IAthlete athlete)
        {
            throw new NotImplementedException();
        }

        public void AddEquipment(IEquipment equipment)
        {
            throw new NotImplementedException();
        }

        public void Exercise()
        {
            throw new NotImplementedException();
        }

        public string GymInfo()
        {
            throw new NotImplementedException();
        }

        public bool RemoveAthlete(IAthlete athlete)
        {
            throw new NotImplementedException();
        }
    }
}
