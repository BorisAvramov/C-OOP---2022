﻿using Heroes.Core.Contracts;
using Heroes.Models.Contracts;
using Heroes.Models.Heroes;
using Heroes.Repositories;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Heroes.Core
{
    public class Controller : IController
    {

        private HeroRepository heroes;
        private WeaponRepository weapons;


        public string AddWeaponToHero(string weaponName, string heroName)
        {


            throw new NotImplementedException();
        }

        public string CreateHero(string type, string name, int health, int armour)
        {
            if (type != "Knight" && type != "Barbarian")
            {
                throw new InvalidOperationException("Invalid hero type.");
            }
            if (heroes.Models.Any(m => m.Name == name))
            {
                throw new InvalidOperationException($"The hero {name} already exists.");
            }

            IHero hero = null;

            if (type == "Knight")
            {
                hero = new Knight(name, health, armour);

            }
            else
            {
                hero = new Barbarian(name, health, armour);
            }

            return hero is Knight ? $"Successfully added Sir {name} to the collection." : $"Successfully added Barbarian {name} to the collection.";
        }

        public string CreateWeapon(string type, string name, int durability)
        {
            throw new NotImplementedException();
        }

        public string HeroReport()
        {
            throw new NotImplementedException();
        }

        public string StartBattle()
        {
            throw new NotImplementedException();
        }
    }
}
