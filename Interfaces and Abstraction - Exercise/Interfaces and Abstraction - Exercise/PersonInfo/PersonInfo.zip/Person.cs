﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PersonInfo
{
    public abstract class Person : IPerson
    {
        protected Person(string name, int age)
        {
            Name = name;
            Age = age;
        }

        public string Name { get; }

        public int Age { get; }
    }
}
