﻿using Gym.Models.Equipment;
using Gym.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace Gym.Repositories
{
    public class EquipmentRepository : IRepository<Equipment>
    {
        public IReadOnlyCollection<Equipment> Models => throw new NotImplementedException();

        public void Add(Equipment model)
        {
            throw new NotImplementedException();
        }

        public Equipment FindByType(string type)
        {
            throw new NotImplementedException();
        }

        public bool Remove(Equipment model)
        {
            throw new NotImplementedException();
        }
    }
}
