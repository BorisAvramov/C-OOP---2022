﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CustomRandomList
{
    public  class RandomList<T> : List<T>
        where T : class
    {

        //public RandomList(List<string> list)
        //{

        //    this.List = list;

        //}

        //public List<string> List { get; set; }

        public T RandomString()
        {
            Random rnd = new Random();

            int index = rnd.Next(0, this.Count);
            T elemnent = this[index];
            this.RemoveAt(index);
            return elemnent;

        }
    }
}
