﻿using NUnit.Framework;
using Skeleton.Contracts;
using Skeleton.Tests.Fake;
using System;
using System.Collections.Generic;
using System.Text;

namespace Skeleton.Tests
{
    public class HeroTests
    {
        [Test]

        public void Test_IfHeroGainXP_WhenTargetDies()
        {
            IWeapon weapon = new fakeWeapon();
            ITarget target = new fakeTarget();

            Hero hero = new Hero(weapon, target);

            hero.HerosWeaponeAttack(weapon, target);

            Assert.AreEqual(60, hero.experience);


            

        }

    }
}
