﻿using PlanetWars.Core.Contracts;
using PlanetWars.Models.MilitaryUnits;
using PlanetWars.Models.MilitaryUnits.Contracts;
using PlanetWars.Models.Planets;
using PlanetWars.Models.Planets.Contracts;
using PlanetWars.Models.Weapons;
using PlanetWars.Models.Weapons.Contracts;
using PlanetWars.Repositories;
using PlanetWars.Utilities.Messages;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PlanetWars.Core
{
    public class Controller : IController
    {
        private PlanetRepository    planets;


        public Controller()
        {
            planets = new PlanetRepository();
        }



        public string AddUnit(string unitTypeName, string planetName)
        {
            IPlanet planet = planets.FindByName(planetName);

            if (planet == null)
            {
                throw new InvalidOperationException(String.Format(ExceptionMessages.UnexistingPlanet, planetName));
            }

            if (unitTypeName != "AnonymousImpactUnit" && unitTypeName != "SpaceForces" && unitTypeName != "StormTroopers")
            {
                throw new InvalidOperationException(String.Format(ExceptionMessages.ItemNotAvailable, unitTypeName));
            }

            IMilitaryUnit unit = null;

            if (unitTypeName == "AnonymousImpactUnit")
            {
                unit = new AnonymousImpactUnit();
            }
            else if (unitTypeName == "SpaceForces")
            {
                unit = new SpaceForces();

            }
            else if (unitTypeName == "StormTroopers")
            {
                unit = new StormTroopers();

            }

            if (planet.Army.Contains(unit))
            {
                throw new InvalidOperationException(String.Format(ExceptionMessages.UnitAlreadyAdded, unitTypeName, planetName));

            }

            planet.AddUnit(unit);

            planet.Spend(unit.Cost);
            return $"{unitTypeName} added successfully to the Army of {planetName}!";

        }

        public string AddWeapon(string planetName, string weaponTypeName, int destructionLevel)
        {
            IPlanet planet = planets.FindByName(planetName);

            if (planet == null)
            {
                throw new InvalidOperationException(String.Format(ExceptionMessages.UnexistingPlanet, planetName));
            }

            if (weaponTypeName != "BioChemicalWeapon" && weaponTypeName != "NuclearWeapon" && weaponTypeName != "SpaceMissiles")
            {
                throw new InvalidOperationException(String.Format(ExceptionMessages.ItemNotAvailable, weaponTypeName));
            }


            IWeapon weapon = null;

            if (weaponTypeName == "BioChemicalWeapon")
            {
                weapon = new BioChemicalWeapon(destructionLevel);
            }
            else if (weaponTypeName == "NuclearWeapon")
            {
                weapon = new NuclearWeapon(destructionLevel);

            }
            else if (weaponTypeName == "SpaceMissiles")
            {
                weapon = new SpaceMissiles(destructionLevel);

            }



            if (planet.Weapons.Contains(weapon))
            {
                throw new InvalidOperationException(String.Format(ExceptionMessages.WeaponAlreadyAdded, weaponTypeName, planetName));

            }

            planet.AddWeapon(weapon);

            planet.Spend(weapon.Price);
            return $"{planetName} purchased {weaponTypeName}!";


        }

        public string CreatePlanet(string name, double budget)
        {
            IPlanet planet = planets.FindByName(name);
            if (planet != null)
            {
                return $"Planet {name} is already added!";
            }
            IPlanet planetToAdd = new Planet(name, budget);
            planets.AddItem(planetToAdd);
            return $"Successfully added Planet: {name}";

        }

        public string ForcesReport()
        {

            throw new NotImplementedException();
        }

        public string SpaceCombat(string planetOne, string planetTwo)
        {
            IPlanet planet1 = planets.FindByName(planetOne);
            IPlanet planet2 = planets.FindByName(planetTwo);

            bool isplanet1haveNuclear = planet1.Weapons.Any(w => w.GetType().Name == "NuclearWeapon");
            bool isplanet2haveNuclear = planet2.Weapons.Any(w => w.GetType().Name == "NuclearWeapon");

            if (planet1.MilitaryPower == planet2.MilitaryPower)
            {
                if ((isplanet1haveNuclear == true && isplanet2haveNuclear == true)||
                    (isplanet1haveNuclear == false && isplanet2haveNuclear == false))
                {
                    planet1.Spend(planet1.Budget / 2);
                    planet2.Spend(planet2.Budget / 2);

                    return $"The only winners from the war are the ones who supply the bullets and the bandages!";

                }

                if (isplanet1haveNuclear == true && isplanet2haveNuclear == false)
                {
                    
                    planet1.Spend(planet1.Budget / 2);
                    var leftbudget = planet2.Budget - (planet2.Budget / 2);
                    planet2.Spend(planet2.Budget / 2);

                    planet1.Profit(planet2.Budget / 2);
                    planet2.Spend(planet2.Budget);

                    


                }
                if (isplanet1haveNuclear == false && isplanet2haveNuclear == true)
                {

                    planet2.Spend(planet2.Budget / 2);
                    var leftbudget = planet1.Budget - (planet1.Budget / 2);
                    planet1.Spend(planet1.Budget / 2);

                    planet2.Profit(planet1.Budget / 2);
                    planet1.Spend(planet1.Budget);


                }

            }

           



            throw new NotImplementedException();
        }

        public string SpecializeForces(string planetName)
        {
            IPlanet planet = planets.FindByName(planetName);
            if (planet == null)
            {
                throw new InvalidOperationException(String.Format(ExceptionMessages.UnexistingPlanet, planetName));
            }

            if (planet.Army.Count == 0)
            {
                throw new InvalidOperationException(String.Format(ExceptionMessages.NoUnitsFound));

            }

            planet.Spend(1.25);
            planet.TrainArmy();

            return $"{planetName} has upgraded its forces!";
        }
    }
}
