﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace PersonsInfo
{
    public class StartUp
    {
        static void Main(string[] args)
        {

            int intValue = int.Parse(Console.ReadLine());


            List<Person> persons = new List<Person>();

            for (int i = 0; i < intValue; i++)
            {

                string[] stringElements = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);

                string firstName = stringElements[0];
                string lastName = stringElements[1];
                int age = int.Parse(stringElements[2]);

                Person curPerson = new Person(firstName, lastName, age);
                persons.Add(curPerson);

            }


            foreach (var person in persons.OrderBy(p => p.FirstName).ThenBy(p => p.Age))
            {

                Console.WriteLine(person);

            }


        }
    }
}
