﻿using System;
using System.Collections.Generic;

namespace BorderControl
{
    public class Program
    {
      public  static void Main(string[] args)
        {
            List <IIdentifiable> identifiables = new List <IIdentifiable>();

            while (true)
            {
                string input = Console.ReadLine();
                if (input == "End")
                {
                    break;
                }
                string[] stringElements = input.Split(" ", StringSplitOptions.RemoveEmptyEntries);

                if (stringElements.Length == 3)
                {
                    string name = stringElements[0];
                    int age = int.Parse(stringElements[1]);
                    string id = stringElements[2];
                    IIdentifiable citizen = new Citizen(name, age, id);
                    identifiables.Add(citizen);
                }
                else if (stringElements.Length == 2)
                {
                    string model = stringElements[0];
                    string id = stringElements[1];
                   IIdentifiable robot = new Robot(model, id);
                    identifiables.Add(robot);
                }
                
            }
            string lastDigits = Console.ReadLine();

            foreach (var item in identifiables)
            {
                if (item.Id.EndsWith(lastDigits))
                {
                    Console.WriteLine(item.Id);
                }
            }
        }
    }
}
