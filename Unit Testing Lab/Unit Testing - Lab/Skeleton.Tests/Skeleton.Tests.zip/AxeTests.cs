using NUnit.Framework;
using System;

namespace Skeleton.Tests
{
    [TestFixture]
    public class AxeTests
    {


        [Test]
        public void doesAxeLoseDurabilityWnenattack()
        {
            Axe axe = new Axe(5, 2);
            Dummy target = new Dummy(10, 20);

            axe.Attack(target);

            Assert.AreEqual(1, axe.DurabilityPoints);
            


        }
        [Test]

        public void ChechAxeIsBroken()
        {
            Axe axe = new Axe(10, 0);





            Assert.Throws<InvalidOperationException>(() =>

            axe.Attack(new Dummy(20, 20))
            , "Brokean Weapon");


        }
    }
}