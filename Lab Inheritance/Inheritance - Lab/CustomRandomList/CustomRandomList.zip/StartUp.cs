﻿using System;
using System.Collections.Generic;

namespace CustomRandomList
{
    public class StartUp
    {
        static void Main(string[] args)
        {



            RandomList myList = new RandomList(new List<string> {"pesho", "mimi", "koko" });

            Console.WriteLine( myList.RandomString());


            //myList.Add("borko");

        }
    }
}
