﻿using PlanetWars.Models.Planets;
using PlanetWars.Models.Planets.Contracts;
using PlanetWars.Repositories.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PlanetWars.Repositories
{
    public class PlanetRepository : IRepository<IPlanet>
    {

        private readonly HashSet<IPlanet> models;

        public PlanetRepository()
        {
            models = new HashSet<IPlanet>();
        }

        public IReadOnlyCollection<IPlanet> Models => models;



        public void AddItem(IPlanet model)
        {
            models.Add(model);

        }

        public IPlanet FindByName(string name)
        {
            IPlanet planet = models.FirstOrDefault(p => p.GetType().Name == name);
            return planet;


        }

        public bool RemoveItem(string name)
        {
            IPlanet planet = models.FirstOrDefault(p => p.GetType().Name == name);

            if (planet != null)
            {
                models.Remove(planet);
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
