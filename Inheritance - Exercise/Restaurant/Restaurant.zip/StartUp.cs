﻿namespace Restaurant
{
    public class StartUp
    {
        public static void Main(string[] args)
        {


            Coffee coffee = new Coffee("lavaca", 12.5);


            Fish fish = new Fish("som",12.5m);
        }
    }
}